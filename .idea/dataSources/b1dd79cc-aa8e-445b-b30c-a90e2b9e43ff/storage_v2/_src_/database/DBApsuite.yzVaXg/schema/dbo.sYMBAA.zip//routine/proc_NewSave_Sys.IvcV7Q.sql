
CREATE PROCEDURE [proc_NewSave_Sys]
(
	 @uniqueguid_2 	[varchar](36),
	 @uniqueid_3 	[varchar](32),
	 @agent_4 	[varchar](16),
	 @callid_5 	[varchar](24),
	 @calledid_6 	[varchar](24),
	 @extention_7 	[varchar](16),
	 @preid_8 	[varchar](16),
	 @nextid_9 	[varchar](16),
	 @starttime_10 	[datetime],
	 @endtime_11 	[datetime],
	 @howtime_12 	[int],
	 @acd_13 	[int],
	 @dins_14 	[int],
	 @inorout_15 	[tinyint],
	 @ifback_16 	[tinyint],
	 @backwhere_17 	[varchar](30),
	 @backpath_18 	[varchar](10),
	 @voicepath_19 	[varchar](32),
	 @datapath_20 	[varchar](32),
	 @files_21 	[varchar](20),
	 @whereplace_22 	[varchar](30),
	 @voicesize_23 	[int],
	 @datasize_24 	[int],
	 @restorepath_25        [varchar](64),

         @columns_1     char(50),
         @columns_2     char(50),
         @columns_3     char(50),
         @columns_4     char(50),
         @columns_5     char(50),
         @columns_6     char(50),
         @columns_7     char(50),
         @columns_8     char(50),
         @columns_9     char(50),
         @columns_10    char(50))
AS
Begin 
   declare @ret int
  -- set @ret=1
   select lsh from t_sys
     where uniqueguid = @Uniqueguid_2
     
   if @@RowCount>0 ---update t_sys
   begin
     --if @voicepath_19 <> '' 
     --begin
       UPDATE [dbo].[t_sys] 
       SET     
		[agent]=@agent_4,
		[callid]=@callid_5,
		[calledid]=@calledid_6,
		[preid]=@preid_8,
		[nextid]=@nextid_9, 
		[endtime]=@endtime_11,
		[howtime]=@howtime_12,
		[inorout]=@inorout_15,
		[voicepath]=@voicepath_19,
		[voicesize]=@voicesize_23

       WHERE 
	       ( [uniqueguid]	 = @uniqueguid_2)
     --end
     if @datapath_20 <> ''
     begin
       UPDATE [dbo].[t_sys] 
 
       SET      [datapath]	 = @datapath_20,
	        [datasize]	 = @datasize_24

       WHERE 
                ( [uniqueguid]	 = @uniqueguid_2)
     end
     if @columns_1 <> ''  UPDATE [dbo].[t_sys] SET columns_1 = @columns_1 WHERE ( [uniqueguid]	 = @uniqueguid_2);
     if @columns_2 <> ''  UPDATE [dbo].[t_sys] SET columns_2 = @columns_2 WHERE ( [uniqueguid]	 = @uniqueguid_2);
     if @columns_3 <> ''  UPDATE [dbo].[t_sys] SET columns_3 = @columns_3 WHERE ( [uniqueguid]	 = @uniqueguid_2);
     if @columns_4 <> ''  UPDATE [dbo].[t_sys] SET columns_4 = @columns_4 WHERE ( [uniqueguid]	 = @uniqueguid_2);
     if @columns_5 <> ''  UPDATE [dbo].[t_sys] SET columns_5 = @columns_5 WHERE ( [uniqueguid]	 = @uniqueguid_2);
     if @columns_6 <> ''  UPDATE [dbo].[t_sys] SET columns_6 = @columns_6 WHERE ( [uniqueguid]	 = @uniqueguid_2);
     if @columns_7 <> ''  UPDATE [dbo].[t_sys] SET columns_7 = @columns_7 WHERE ( [uniqueguid]	 = @uniqueguid_2);
     if @columns_8 <> ''  UPDATE [dbo].[t_sys] SET columns_8 = @columns_8 WHERE ( [uniqueguid]	 = @uniqueguid_2);
     if @columns_9 <> ''  UPDATE [dbo].[t_sys] SET columns_9 = @columns_9 WHERE ( [uniqueguid]	 = @uniqueguid_2);
     if @columns_10 <> '' UPDATE [dbo].[t_sys] SET columns_10 = @columns_10 WHERE ( [uniqueguid]	 = @uniqueguid_2);
   
     if @@error<>0 
       return @@error
     else
       return (1) --procedure exec successful
   end

   else  ----insert a new record to t_sys
   begin
     declare @lsh_1 	[numeric]
     INSERT INTO [dbo].[t_sys] 
	 (
	 [uniqueguid],
	 [uniqueid],
	 [agent],
	 [callid],
	 [calledid],
	 [extention],
	 [preid],
	 [nextid],
	 [starttime],
	 [endtime],
	 [howtime],
	 [acd],
	 [dins],
	 [inorout],
	 [ifback],
	 [backwhere],
	 [backpath],
	 [voicepath],
	 [datapath],
	 [files],
	 [whereplace],
	 [voicesize],
	 [datasize],
	 [restorepath],

         [columns_1],
         [columns_2],
         [columns_3],
         [columns_4],
         [columns_5],
         [columns_6],
         [columns_7],
         [columns_8],
         [columns_9],
         [columns_10]) 
 
     VALUES 
	(
	 @uniqueguid_2,
	 @uniqueid_3,
	 @agent_4,
	 @callid_5,
	 @calledid_6,
	 @extention_7,
	 @preid_8,
	 @nextid_9,
	 @starttime_10,
	 @endtime_11,
	 @howtime_12,
	 @acd_13,
	 @dins_14,
	 @inorout_15,
	 @ifback_16,
	 @backwhere_17,
	 @backpath_18,
	 @voicepath_19,
	 @datapath_20,
	 @files_21,
	 @whereplace_22,
	 @voicesize_23,
	 @datasize_24,
	 @restorepath_25,

         @columns_1,
         @columns_2,
         @columns_3,
         @columns_4,
         @columns_5,
         @columns_6,
         @columns_7,
         @columns_8,
         @columns_9,
         @columns_10)
     if @@error<>0 
       return (@@error)
     else
       return(1) --procedure exec successful      
   end
end

go

