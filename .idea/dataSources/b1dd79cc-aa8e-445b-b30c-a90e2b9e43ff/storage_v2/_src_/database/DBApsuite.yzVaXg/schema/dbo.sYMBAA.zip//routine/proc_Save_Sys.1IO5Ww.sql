
CREATE PROCEDURE [proc_Save_Sys]
(
	 @uniqueguid_2 	[varchar](36),
	 @uniqueid_3 	[varchar](32),
	 @agent_4 	[varchar](16),
	 @callid_5 	[varchar](24),
	 @calledid_6 	[varchar](24),
	 @extention_7 	[varchar](16),
	 @preid_8 	[varchar](16),
	 @nextid_9 	[varchar](16),
	 @starttime_10 	[datetime],
	 @endtime_11 	[datetime],
	 @howtime_12 	[int],
	 @acd_13 	[int],
	 @dins_14 	[int],
	 @inorout_15 	[tinyint],
	 @ifback_16 	[tinyint],
	 @backwhere_17 	[varchar](30),
	 @backpath_18 	[varchar](10),
	 @voicepath_19 	[varchar](32),
	 @datapath_20 	[varchar](32),
	 @files_21 	[varchar](20),
	 @whereplace_22 	[varchar](30),
	 @voicesize_23 	[int],
	 @datasize_24 	[int],
	 @restorepath_25 	[varchar](64))
AS
Begin 
   declare @ret int
  -- set @ret=1
   select lsh from t_sys
     where uniqueguid = @Uniqueguid_2
   if @@RowCount>0 ---update t_sys
   begin
     EXECUTE  @ret=proc_update_t_sys	 @uniqueguid_2 ,
			 		 @preid_8 ,	
					 @nextid_9,
					 @endtime_11, 	
					 @howtime_12,
					 @agent_4,
					 @callid_5,
					 @calledid_6,
					 @inorout_15
     return @ret
   
   end
   else  ----insert a new record to t_sys
   begin
     EXECUTE @ret=proc_insert_t_sys 	 @uniqueguid_2,
					 @uniqueid_3,
					 @agent_4,
					 @callid_5,
					 @calledid_6,
					 @extention_7,
					 @preid_8,
					 @nextid_9,
					 @starttime_10,
					 @endtime_11,
					 @howtime_12,
					 @acd_13,
					 @dins_14,
					 @inorout_15,
					 @ifback_16,
					 @backwhere_17,
					 @backpath_18,
					 @voicepath_19,
					 @datapath_20,
					 @files_21,
					 @whereplace_22,
					 @voicesize_23,
					 @datasize_24,
					 @restorepath_25
     return @ret
      
   end
end


go

