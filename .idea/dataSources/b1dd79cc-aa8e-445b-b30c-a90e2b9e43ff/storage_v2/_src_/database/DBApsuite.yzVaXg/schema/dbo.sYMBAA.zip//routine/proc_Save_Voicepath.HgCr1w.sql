

CREATE PROCEDURE [proc_Save_Voicepath]
	(@uniqueguid_1 	[varchar](36),
	 @voicepath_2 	[varchar](32),
	 @voicesize_3 	[int])


AS 
Begin
    select [lsh] from t_sys
    where [uniqueguid] = @uniqueguid_1
    if @@rowcount<=0 
      return(0)  --didn't found the apointed record
    else  
    begin
      UPDATE [DBApsuite].[dbo].[t_sys] 

      SET  [voicepath]	 = @voicepath_2,
           [voicesize]	 = @voicesize_3 

      WHERE 
	( [uniqueguid]	 = @uniqueguid_1)
      if @@error<>0 
         return(@@error)  --update failed        	
      else
         return(1)  --procedure exec successful
    end
end


go

