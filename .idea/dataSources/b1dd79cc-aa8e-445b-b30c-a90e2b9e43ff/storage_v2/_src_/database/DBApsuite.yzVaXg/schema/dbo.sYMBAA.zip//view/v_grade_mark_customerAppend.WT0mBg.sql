
CREATE VIEW dbo.v_grade_mark_customerAppend
AS
SELECT dbo.t_sys.lsh, dbo.t_sys.uniqueguid, dbo.t_sys.uniqueid, dbo.t_sys.agent, 
      dbo.t_sys.callid, dbo.t_sys.calledid, dbo.t_sys.extention, dbo.t_sys.preid, 
      dbo.t_sys.nextid, dbo.t_sys.starttime, dbo.t_sys.endtime, dbo.t_sys.howtime, 
      dbo.t_sys.acd, dbo.tx_account.account_alias AS dins, dbo.t_sys.inorout, dbo.t_sys.ifback, 
      dbo.t_sys.backwhere, dbo.t_sys.backpath, dbo.t_sys.voicepath, dbo.t_sys.datapath, 
      dbo.t_sys.files, dbo.t_sys.whereplace, dbo.t_sys.voicesize, dbo.t_sys.datasize, 
      dbo.t_sys.restorepath, dbo.t_lastgradedinfo.grade, dbo.t_lastgradedinfo.remark, 
      dbo.t_sys.columns_1, dbo.t_sys.columns_2, dbo.t_sys.columns_3, 
      dbo.t_sys.columns_4, dbo.t_sys.columns_5, dbo.t_sys.columns_6, 
      dbo.t_sys.columns_7, dbo.t_sys.columns_8, dbo.t_sys.columns_9, 
      dbo.t_sys.columns_10
FROM dbo.t_sys LEFT OUTER JOIN
      dbo.tx_account ON 
      dbo.t_sys.agent = dbo.tx_account.account_name LEFT OUTER JOIN
      dbo.t_lastgradedinfo ON dbo.t_sys.uniqueguid = dbo.t_lastgradedinfo.uniqueguid

go

