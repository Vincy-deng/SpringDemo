
--创建视图--
CREATE VIEW dbo.view_sys
AS
SELECT lsh, uniqueguid, uniqueid AS CustomerCardID  , agent, callid AS callNo , 
      calledid AS calledNo, extention, preid, nextid, starttime, endtime, howtime, 
      acd AS CallID, Dins AS CTICallTime, inorout, ifback, backwhere, backpath, voicepath, 
      datapath, files, whereplace, voicesize, datasize, restorepath
FROM dbo.t_sys

go

