

CREATE PROCEDURE [dbo].[CanRecord]
	@who char(16),
	@which_day int,
	@which_hour int,
        @time_set bigint output

AS
--采用bigint保存一天的录音时间设置
	declare @monday bigint ,@tuesday bigint ,@wednesday bigint,@thursday bigint,@friday bigint,@saturday bigint,@sunday bigint
	declare @hour_bit int,@target_value int,@target_day_value bigint

	if @which_day<1 or @which_day>7 return -1 --参数错误
	if @which_hour<0 or @which_hour>47 return -1 --参数错误

	select  @monday=monday_set,@tuesday=tuesday_set,@wednesday=wednesday_set,@thursday=thursday_set,
		@friday=friday_set,@saturday=saturday_set,@sunday=sunday_set from view_AgentRecordTime where 
		account_name=@who

	if @@rowcount=1 and @@error=0 
	begin
	    	
		if @which_day=1 set @target_day_value = @monday
		else if @which_day=2 set @target_day_value = @tuesday
		else if @which_day=3 set @target_day_value = @wednesday
		else if @which_day=4 set @target_day_value = @tuesday
		else if @which_day=5 set @target_day_value = @friday
		else if @which_day=6 set @target_day_value = @saturday
		else if @which_day=7 set @target_day_value = @sunday
		
		/*
                           set @hour_bit = power(2,@which_hour)
		if (@target_value&@hour_bit)>0 return 1 --can record
		else return 0 --can't be recorded
                           */
                          set @time_set=@target_day_value
		return 0
	end
	if @@rowcount=0 and @@error=0 return -2  --无匹配记录
	if @@rowcount>1 and @@error=0 return -3  --多于一条匹配记录
	if @@error!=0 return -4 --数据库错误


go

