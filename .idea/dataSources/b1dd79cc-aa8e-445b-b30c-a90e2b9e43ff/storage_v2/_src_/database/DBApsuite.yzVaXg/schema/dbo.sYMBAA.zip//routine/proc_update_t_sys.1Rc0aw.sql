

CREATE PROCEDURE [proc_update_t_sys]
	(@uniqueguid_1 	[varchar](36),
	 @preid_2 	[varchar](16),
	 @nextid_3 	[varchar](16),
	 @endtime_4 	[datetime],
	 @howtime_5 	[int],
	 @agent_6 	[varchar](16),
	 @callid_7 	[varchar](24),
	 @calledid_8 	[varchar](24),
	 @inorout_9 	[tinyint])


AS
Begin
 
 if @nextid_3 = '' 
begin
 UPDATE [DBApsuite].[dbo].[t_sys] 
 
  SET      [preid]	 = @preid_2,
	   [nextid]	 = @nextid_3,
	   [endtime]	 = @endtime_4,
	   [howtime]	 = @howtime_5,
	   [agent]	 = @agent_6,
	   --,
	   [callid]	 = @callid_7,
	   [calledid]	 = @calledid_8,
	   [inorout]	 = @inorout_9

  WHERE 
	( [uniqueguid]	 = @uniqueguid_1)
end
else 
begin
 UPDATE [DBApsuite].[dbo].[t_sys] 
 
  SET      [preid]	 = @preid_2,
	   [nextid]	 = @nextid_3,
	   [endtime]	 = @endtime_4,
	   [howtime]	 = @howtime_5,
	   [agent]	 = @agent_6,
	   --,
	   [callid]	 = @callid_7,
	   [calledid]	 = @calledid_8,
	   [inorout]	 = @inorout_9

  WHERE 
	( [uniqueguid]	 = @uniqueguid_1)
end
  if @@error<>0 
    return @@error
  else
    return (1) --procedure exec successful
end

go

