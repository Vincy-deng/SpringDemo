
CREATE PROCEDURE [proc_Save_Datapath]
	(@uniqueguid_1 	[varchar](36),
	 @datapath_2 	[varchar](32),
	 @datasize_3 	[int])


AS 
Begin
    select [lsh] from t_sys
    where [uniqueguid] = @uniqueguid_1
    if @@rowcount<=0 
      return(0)  --didn't found the apointed record
    else  
    begin
      UPDATE [DBApsuite].[dbo].[t_sys] 

      SET  [datapath]	 = @datapath_2,
           [datasize]	 = @datasize_3 

      WHERE 
	( [uniqueguid]	 = @uniqueguid_1)
      if @@error<>0 
         return(@@error)  --update failed        	
      else
         return(1)  --procedure exec successful
    end
end
go

