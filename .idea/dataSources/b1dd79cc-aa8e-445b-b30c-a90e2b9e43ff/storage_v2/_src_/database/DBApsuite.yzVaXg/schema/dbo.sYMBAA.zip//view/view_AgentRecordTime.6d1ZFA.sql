
CREATE VIEW dbo.view_AgentRecordTime
AS
SELECT a.account_name, b.monday_set, b.tuesday_set, b.wednesday_set, b.thursday_set, 
      b.friday_set, b.saturday_set, b.sunday_set
FROM dbo.tx_account a INNER JOIN
      dbo.tx_AgentRecordTime b ON a.account_id = b.agent_id



go

