CREATE VIEW dbo.sysutility_ucp_computer_cpu_utilization AS
(   
    -- computer_object_type = 3
    -- processor_resource_type = 3
    -- target_type = 1

    SELECT cp.physical_server_name as physical_server_name
        , SUM(CASE WHEN cp.utilization_type = 1 THEN 1 ELSE 0 END) AS under_utilized_count
        , SUM(CASE WHEN cp.utilization_type = 2 THEN 1 ELSE 0 END) AS over_utilized_count
    FROM msdb.dbo.sysutility_ucp_computer_policies cp 
		INNER JOIN msdb.dbo.sysutility_ucp_policy_violations pv
			ON cp.policy_id = pv.policy_id AND cp.powershell_path = pv.target_query_expression
    WHERE cp.resource_type = 3
        AND cp.target_type = 1
    GROUP BY cp.physical_server_name    
    
)
go

