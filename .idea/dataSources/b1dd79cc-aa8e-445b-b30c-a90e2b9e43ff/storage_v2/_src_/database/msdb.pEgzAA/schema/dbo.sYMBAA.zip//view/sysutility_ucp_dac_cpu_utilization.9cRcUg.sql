CREATE VIEW dbo.sysutility_ucp_dac_cpu_utilization AS
( 
    -- dac_object_type = 1
    -- processor_resource_type = 3
    -- target_type = 5

    SELECT dp.dac_name
        , dp.dac_server_instance_name
        , SUM(CASE WHEN dp.utilization_type = 1 THEN 1 ELSE 0 END) AS under_utilized_count
        , SUM(CASE WHEN dp.utilization_type = 2 THEN 1 ELSE 0 END) AS over_utilized_count
    FROM msdb.dbo.sysutility_ucp_dac_policies AS dp
		INNER JOIN msdb.dbo.sysutility_ucp_policy_violations pv
			ON dp.policy_id = pv.policy_id AND dp.powershell_path = pv.target_query_expression
    WHERE dp.resource_type = 3
        AND dp.target_type = 5
    GROUP BY dp.dac_name, dp.dac_server_instance_name
    
)
go

