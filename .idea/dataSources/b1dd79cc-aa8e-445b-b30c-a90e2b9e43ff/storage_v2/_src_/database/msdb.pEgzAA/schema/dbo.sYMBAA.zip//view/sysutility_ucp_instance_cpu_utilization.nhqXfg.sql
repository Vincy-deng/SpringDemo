CREATE VIEW dbo.sysutility_ucp_instance_cpu_utilization AS
(    
    -- server_object_type = 2
    -- processor_resource_type = 3
    -- target_type = 4
	
    SELECT ip.server_instance_name AS server_instance_name
        , SUM(CASE WHEN ip.utilization_type = 1 THEN 1 ELSE 0 END) AS under_utilized_count
        , SUM(CASE WHEN ip.utilization_type = 2 THEN 1 ELSE 0 END) AS over_utilized_count
    FROM msdb.dbo.sysutility_ucp_instance_policies ip
		INNER JOIN msdb.dbo.sysutility_ucp_policy_violations pv
			ON ip.policy_id = pv.policy_id AND ip.powershell_path = pv.target_query_expression
    WHERE ip.resource_type = 3
       AND ip.target_type = 4
    GROUP BY ip.server_instance_name

)
go

